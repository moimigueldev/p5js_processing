function setup() {
	createCanvas(windowWidth, windowHeight);
	// put setup code here
}

function draw() {
	// put drawing code here
}
