let cols, rows;
const size = 50;
const grid = [];

function Node(i, j) {
  this.x = i * size;
  this.y = j * size;
  this.show = () => {
    noFill();
    stroke(255, 255, 255, 10);
    rect(this.x, this.y, size, size);
  };
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  cols = width / size;
  rows = height / size;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid.push(new Node(i, j));
    }
  }
  console.log(grid);
}

function draw() {
  for (let i = 0; i < grid.length; i++) {
    grid[i].show();
  }

  noLoop();
}
